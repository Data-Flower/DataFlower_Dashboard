const express = require('express');
const app = express();
const fs = require('fs');
const port = 8080;

app.listen(port, function () {
    console.log('listening on ', port);
});

app.get('/', function (req, res) {
    html = fs.readFileSync('index.html');
    res.writeHead(200);
    res.write(html);
    res.end();
});

app.get('/view', function (req, res) {
    html = fs.readFileSync('views/index.html');
    res.writeHead(200);
    res.write(html);
    res.end();
});

app.get('/test', function (req, res) {
    res.send('the REST endpoint test run!');
});